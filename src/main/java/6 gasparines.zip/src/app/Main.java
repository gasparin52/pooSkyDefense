package pooskydefense.app;

import pooskydefense.controlador.Controlador;
import pooskydefense.modelo.Direccion;
import pooskydefense.modelo.Game;

// Punto de entrada del programa con datos fijos de prueba.

public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        Controlador controlador = new Controlador(game);

        controlador.moverAvion(Direccion.DERECHA);
        controlador.cambiarAltitudAvion(3200);

        for (int i = 1; i <= 20; i++) {
            game.tick();
        }

        System.out.println("Nivel actual: " + game.getNivel());
        System.out.println("Puntos: " + game.getJugador().getPuntos());
        System.out.println("Vidas: " + game.getJugador().getVidas());
        System.out.println("Energia del avion: " + game.getJugador().getAvion().getEnergia());
    }
}
